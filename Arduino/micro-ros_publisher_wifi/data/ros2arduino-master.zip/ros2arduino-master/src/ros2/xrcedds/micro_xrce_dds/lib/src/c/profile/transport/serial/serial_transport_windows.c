#include <uxr/client/profile/transport/serial/serial_transport_platform.h>

#if defined(UCLIENT_PLATFORM_WINDOWS)
#include <uxr/client/profile/transport/serial/serial_transport_windows.h>
#endif
