#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif

uint32_t dds_getMilliseconds(void);
uint32_t dds_getMicroseconds(void);

#ifdef __cplusplus
}
#endif